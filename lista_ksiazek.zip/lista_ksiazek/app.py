from flask import Flask, render_template, request, json, redirect, url_for

#from api_tests folder:
import click
from flask.cli import with_appcontext
from werkzeug.security import generate_password_hash
#from api_tests folder up code

#from Tkinter import *

#NOT WORKING from: MySQL *******************
#from flask_mysqldb import MySQL
#import MySQLdb.cursors
#from flask_sqlalchemy import SQLAlchemy
#from flaskext.mysql import MySQL
#*******************************************

app = Flask(__name__)

@app.route ('/')
def index():
    return render_template('BasePage.html')

@app.route("/list")
def nowe():
    return render_template('list.html')

@app.route('/second_page')
def second():
    return render_template('index.html')

@app.route('/showSignUp')
def showSignUp():
    return render_template('signup.html')

@app.route('/signUp', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['name'] != 'inputName' or request.form['inputPassword'] != 'inputName' or request.form['inputEmail'] != 'inputEmail':
            error = 'Nieprawidłowe dane. Spróbuj jeszcze raz.'
        else:
            return redirect(url_for('index'))
    return render_template('signUp.html', error=error)

#other version of signup:
#@app.route('/signUp',methods=['POST'])
#def signUp():
 
    #_name = request.form['inputName']
    #_email = request.form['inputEmail']
    #_password = request.form['inputPassword']

    #if _name and _email and _password:
        #return json.dumps({'html':'<span>Wszystkie pola ok!</span>'})
    #else:
        #return json.dumps({'html':'<span>Uzupełnij wymagane pola</span>'}) 

@app.route('/books')
def listBooks():
    return redirect('https://www.googleapis.com/books/v1/volumes?q=Hobbit')

if __name__ == '__main__':
    app.run ('localhost', 4449)
